/* ─────────────────────────────────────────────────────────
   Atlas — small interaction layer
   • Smooth scroll for nav links
   • Scroll-spy that toggles .is-active on the right nav link
   • Continent radial: 7 spokes + endpoints (3 done, 4 pending)
   • Pilot stairs: 10 cells, ~71% filled
   • Country dotmatrix: 196 dots, 11 lit, hover reveals country name
   • Piano keyboard: octave with a few "learned" keys highlighted
   ───────────────────────────────────────────────────────── */

(function () {
  /* ─── nav ───────────────────────────────── */
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = ['index', 'now', 'experience', 'goals'].map((id) => document.getElementById(id));

  navLinks.forEach((a) => {
    a.addEventListener('click', (e) => {
      const href = a.getAttribute('href');
      if (!href || !href.startsWith('#')) return;
      e.preventDefault();
      const t = document.getElementById(href.slice(1));
      if (t) window.scrollTo({ top: t.offsetTop - 60, behavior: 'smooth' });
    });
  });

  const onScroll = () => {
    const y = window.scrollY + 100;
    let active = sections[0];
    for (const s of sections) if (s && s.offsetTop <= y) active = s;
    navLinks.forEach((a) => {
      a.classList.toggle('is-active', a.getAttribute('href') === '#' + (active && active.id));
    });
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ─── continent radial ──────────────────── */
  const cg = document.getElementById('continents');
  if (cg) {
    const continents = [
      { name: 'NA', done: true,  angle: -90 },
      { name: 'SA', done: false, angle: -30 },
      { name: 'EU', done: true,  angle:  30 },
      { name: 'AS', done: true,  angle:  80 },
      { name: 'AF', done: false, angle: 130 },
      { name: 'OC', done: false, angle: 190 },
      { name: 'AN', done: false, angle: 250 },
    ];
    const cx = 110, cy = 110, rOuter = 70, rLabel = 90;
    const ns = 'http://www.w3.org/2000/svg';
    continents.forEach((c) => {
      const rad = (c.angle * Math.PI) / 180;
      const x = cx + Math.cos(rad) * rOuter;
      const y = cy + Math.sin(rad) * rOuter;
      const lx = cx + Math.cos(rad) * rLabel;
      const ly = cy + Math.sin(rad) * rLabel;

      // spoke
      const line = document.createElementNS(ns, 'line');
      line.setAttribute('x1', cx); line.setAttribute('y1', cy);
      line.setAttribute('x2', x);  line.setAttribute('y2', y);
      line.setAttribute('stroke', c.done ? '#1F3FB8' : '#BFB6A0');
      line.setAttribute('stroke-width', c.done ? '1.4' : '0.8');
      line.setAttribute('stroke-dasharray', c.done ? '' : '2 3');
      cg.appendChild(line);

      // endpoint
      const dot = document.createElementNS(ns, 'circle');
      dot.setAttribute('cx', x); dot.setAttribute('cy', y);
      dot.setAttribute('r', c.done ? 5 : 3.5);
      dot.setAttribute('fill', c.done ? '#1F3FB8' : '#F2EBDC');
      dot.setAttribute('stroke', c.done ? '#1F3FB8' : '#BFB6A0');
      dot.setAttribute('stroke-width', '1');
      cg.appendChild(dot);

      // label
      const txt = document.createElementNS(ns, 'text');
      txt.setAttribute('x', lx); txt.setAttribute('y', ly);
      txt.setAttribute('text-anchor', 'middle');
      txt.setAttribute('dominant-baseline', 'middle');
      txt.setAttribute('font-family', 'JetBrains Mono, monospace');
      txt.setAttribute('font-size', '10');
      txt.setAttribute('letter-spacing', '0.1em');
      txt.setAttribute('fill', c.done ? '#1F3FB8' : '#6B665C');
      txt.textContent = c.name;
      cg.appendChild(txt);
    });
  }

  /* ─── pilot stairs ──────────────────────── */
  const stairs = document.getElementById('stairs');
  if (stairs) {
    const total = 10;
    const filledHrs = 71.4;
    const cellHrs = 200 / total; // 20 hr per cell
    for (let i = 0; i < total; i++) {
      const hrsInThis = Math.max(0, Math.min(cellHrs, filledHrs - i * cellHrs));
      const pct = hrsInThis / cellHrs;
      const bar = document.createElement('div');
      bar.className = 'stair-bar' + (pct === 0 ? ' is-empty' : '');
      // height grows with index for the "stair" feel; clipped to actual fill
      const stepHeightPct = 30 + (i / (total - 1)) * 70; // 30%→100%
      bar.style.height = (stepHeightPct * pct) + '%';
      if (pct === 0) bar.style.height = (stepHeightPct * 0.18) + '%';
      stairs.appendChild(bar);
    }
  }

  /* ─── country dotmatrix ─────────────────── */
  const matrix = document.getElementById('dotmatrix');
  const matrixLabel = document.getElementById('dotmatrix-label');
  if (matrix) {
    // 11 visited countries — pinned to a few specific cells so they form
    // a recognizable scatter rather than a strip on the left
    const visited = {
      3: 'Canada', 8: 'United States', 22: 'Mexico',
      45: 'United Kingdom', 51: 'France', 54: 'Germany',
      62: 'Switzerland', 70: 'Italy', 88: 'Singapore',
      102: 'Japan', 138: 'Hong Kong',
    };
    for (let i = 0; i < 196; i++) {
      const d = document.createElement('div');
      d.className = 'dot' + (visited[i] ? ' is-on' : '');
      if (visited[i]) {
        d.dataset.country = visited[i];
        d.title = visited[i];
      }
      d.addEventListener('mouseenter', () => {
        if (matrixLabel) {
          if (visited[i]) {
            matrixLabel.textContent = '✓ ' + visited[i];
            matrixLabel.style.color = 'var(--cobalt)';
          } else {
            matrixLabel.textContent = '— not yet —';
            matrixLabel.style.color = 'var(--ink-mute)';
          }
        }
      });
      matrix.appendChild(d);
    }
    matrix.addEventListener('mouseleave', () => {
      if (matrixLabel) {
        matrixLabel.textContent = 'Hover a dot →';
        matrixLabel.style.color = '';
      }
    });
  }

  /* ─── keyboard ──────────────────────────── */
  const kb = document.getElementById('keyboard');
  if (kb) {
    // 2 octaves of white keys (C..B C..B), with a handful highlighted as
    // "learned" notes from the Chopin nocturne's main theme
    const whiteCount = 14;
    const learned = new Set([0, 2, 4, 7, 9, 11]); // C E G of two octaves
    for (let i = 0; i < whiteCount; i++) {
      const k = document.createElement('div');
      k.className = 'key-white' + (learned.has(i) ? ' is-on' : '');
      kb.appendChild(k);
    }
    // black keys positioned over the white keys: pattern within an octave
    // is between white indices 0-1, 1-2, 3-4, 4-5, 5-6 (skip after E and B)
    const blackOffsets = [0, 1, 3, 4, 5, 7, 8, 10, 11, 12];
    const learnedBlack = new Set([0, 4, 8]);
    blackOffsets.forEach((o, idx) => {
      const b = document.createElement('div');
      b.className = 'key-black' + (learnedBlack.has(idx) ? ' is-on' : '');
      // each white key is 1/whiteCount of the row; black key sits across the
      // boundary at (o+1) — width is 8.5%, so left = (o+1)/14*100 - 4.25
      const leftPct = ((o + 1) / whiteCount) * 100 - 4.25;
      b.style.left = leftPct + '%';
      kb.appendChild(b);
    });
  }
})();
